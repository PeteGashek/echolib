export CLASSPATH=./lib/commons-codec-1.6.jar:./lib/commons-exec-1.3.jar:./lib/commons-logging-1.2.jar:./lib/echolib-0.0.1-SNAPSHOT.jar:./lib/hamcrest-core-1.1.jar:./lib/httpclient-4.3.6.jar:./lib/httpcore-4.4.jar:./lib/jackson-annotations-2.5.1.jar:./lib/jackson-core-2.5.1.jar:./lib/jackson-databind-2.5.1.jar:./lib/json-simple-1.1.1.jar:./lib/jsoup-1.7.3.jar:./lib/junit-4.10.jar:./lib/log4j-1.2.17.jar

java -cp $CLASSPATH com.javasteam.amazon.echo.EchoUserSession
